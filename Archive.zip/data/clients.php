<?php

$clients = [
    "/assets/clients/conoil.webp",
    "/assets/clients/glo.png",
    "/assets/clients/trust.gif",
];
