<?php

$bd = [
    [
        "name" => "Taju Banjo",
        "post" => "Managing Director",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Isaac Olorunfemi (mnse)",
        "post" => "Managing Director",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Jide Banjo",
        "post" => "Managing Director",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Olaide Banjo",
        "post" => "Managing Director",
        "image" => "/7554420.png"
    ],
];


$team = [
    [
        "name" => "Taju Banjo",
        "post" => "Managing Director",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Opeyemi Adeniran (MRS.)",
        "post" => "Head of Operation",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Agunbiade Sikiru",
        "post" => "National Cordinator",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Ade Adeshingbin",
        "post" => "Head, Mechanical Unit",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Barry O. Adams",
        "post" => "Head, Electrical Unit",
        "image" => "/7554420.png"
    ],
    [
        "name" => "Muritala Oluwakemi",
        "post" => "Company Secretary",
        "image" => "/7554420.png"
    ],
];
