<?php

$contacts = [
    [
        "title" => "Head Office",
        "address" => "21/23, Olakunle Ajibade Street, Ogudu-Ojota, Lagos.",
        "tel" => "0807211-4444,01-8104546",
        "email" => "info@deenbanjusengineeringltd.com",
    ],
    [
        "title" => "Ibadan",
        "address" => "Plot 6, Ibadan Abeokuta Express Way, Meridian Bus Stop,
        Apata Ibadan, Oyo State.",
        "tel" => "0807-411-4444"
    ],
    [
        "title" => "DEPORT (AGO)",
        "address" => "Ibadan Abeokuta Road, Opposite First Bank Plc, Apata-Ibadan",
        "tel" => "08058551305"
    ],
    [
        "title" => "Abuja",
        "address" => "Suite A, Mazfalah Plaza, Karu Site, Opposite Water Road, Kanu, Abuja ",
        "tel" => "0807-414-5185"
    ],
    [
        "title" => "Kaduna",
        "address" => "12, HSCH Shopping Complex, Enugu-Port Harcourt Road, Sabo-Ngari, Kano",
        "tel" => "0805-448-4030"
    ],
    [
        "title" => "PORT HARCOURT ",
        "address" => "Jehovah Jireh Plaza, Rumuduru, Port Harcourt.",
        "tel" => "0802-379-2741"
    ],
    [
        "title" => "ENUGU",
        "address" => "5, Railway Commercial Road, Enugu",
        "tel" => "0805-232-7951"
    ],
    [
        "title" => "WARRI",
        "address" => "Ogbori Koko Road, Okumaga Layout, Warri",
        "tel" => "0805-315-2379"
    ],
    [
        "title" => "REPUBLIC OF BENIN",
        "address" => "Quarter Djassin, Port Novo, Republic of Benin",
        "tel" => "+229-98111366"
    ],


];
